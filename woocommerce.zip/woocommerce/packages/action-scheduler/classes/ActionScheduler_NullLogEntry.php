<?php

/**
 * Class ActionScheduler_NullLogEntry
 */
class ActionScheduler_NullLogEntry extends ActionScheduler_LogEntry {
	public function __construct( $action_id = '', $message = '' ) {
		// nothing to see here
	}
}
 