/**
 * Internal dependencies
 */
import type { RegisteredBlocks } from './types';

const registeredBlocks: RegisteredBlocks = {};

export { registeredBlocks };
