/**
 * External dependencies
 */
import Button from '@woocommerce/base-components/button';

export default Button;
