export const STORE_KEY = 'wc/store/collections';
export const DEFAULT_EMPTY_ARRAY = [];
