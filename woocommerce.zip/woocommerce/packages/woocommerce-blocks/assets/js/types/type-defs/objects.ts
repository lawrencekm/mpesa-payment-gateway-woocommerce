export type ObjectType = Record< string, unknown >;
export type EmptyObjectType = Record< string, never >;
