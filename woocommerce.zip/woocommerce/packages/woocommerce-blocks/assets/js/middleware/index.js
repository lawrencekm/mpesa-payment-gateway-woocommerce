/**
 * Internal dependencies
 */
import './store-api-nonce';
